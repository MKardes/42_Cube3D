make fclean; make clean; git add .; git status; git commit -m "Eerr"; git push
